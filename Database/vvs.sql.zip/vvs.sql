-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2021 at 03:04 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) UNSIGNED NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullname`, `username`, `password`) VALUES
(1, 'Md Abu Noman', 'noman', 'noman'),
(2, 'Maria Nusrat', 'maria', 'maria'),
(6, 'Sheik Humayara Sunzida', 'sunzida', 'sunzida');

-- --------------------------------------------------------

--
-- Table structure for table `lost_vehicle_application`
--

CREATE TABLE `lost_vehicle_application` (
  `id` int(11) NOT NULL,
  `nameplate_no` varchar(255) NOT NULL,
  `type` varchar(8) NOT NULL,
  `fir` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lost_vehicle_application`
--

INSERT INTO `lost_vehicle_application` (`id`, `nameplate_no`, `type`, `fir`) VALUES
(2, 'T5243425', 'Bike', 8795685);

-- --------------------------------------------------------

--
-- Table structure for table `register_vehicles`
--

CREATE TABLE `register_vehicles` (
  `si` int(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `dl` int(6) NOT NULL,
  `nid` int(12) NOT NULL,
  `type` varchar(6) NOT NULL,
  `nameplate_no` varchar(8) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register_vehicles`
--

INSERT INTO `register_vehicles` (`si`, `name`, `email`, `dl`, `nid`, `type`, `nameplate_no`, `status`) VALUES
(1, 'Noman', 'mdabunomanma@gmail.com', 542613, 2147483647, 'Bike', 'T5243425', 'Registered'),
(2, 'Maria', 'marianusrat@gmail.com', 789546, 2147483647, 'Car', 'pending', 'pending'),
(3, 'Sunzida', 'sunzidaalpa@gmail.com', 12548744, 1254789654, 'Car', 'pending', 'pending'),
(4, 'Rasel', 'raselhossain@gmail.com', 4579647, 2147483647, 'Bike', 'pending', 'pending'),
(5, 'Billai', 'billal@gmail.com', 458779, 2147483647, 'Bike', 'pending', 'pending'),
(6, 'Saiful', 'saifulislam@gmail.com', 457896, 2147483647, 'Bike', 'T5243426', 'Registered');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullname`, `email`, `username`, `password`) VALUES
(1, 'Md Abu Noman', 'mdabunomanma@gmail.com', 'noman', 'noman'),
(2, 'Maria Nusrat', 'marianusrat@gmail.com', 'maria', 'maria');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fullname` (`fullname`),
  ADD KEY `username` (`username`),
  ADD KEY `password` (`password`);

--
-- Indexes for table `lost_vehicle_application`
--
ALTER TABLE `lost_vehicle_application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register_vehicles`
--
ALTER TABLE `register_vehicles`
  ADD PRIMARY KEY (`si`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique` (`username`),
  ADD KEY `fullname` (`fullname`),
  ADD KEY `email` (`email`),
  ADD KEY `password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lost_vehicle_application`
--
ALTER TABLE `lost_vehicle_application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `register_vehicles`
--
ALTER TABLE `register_vehicles`
  MODIFY `si` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
